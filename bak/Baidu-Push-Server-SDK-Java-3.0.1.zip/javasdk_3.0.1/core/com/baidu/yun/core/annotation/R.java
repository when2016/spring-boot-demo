package com.baidu.yun.core.annotation;

public enum R {
	REQUIRE, OPTIONAL;
}
