package com.baidu.yun.core.filter;

import java.lang.reflect.Field;
import java.util.Map;

public class RegexRestrictFilter implements IFieldFilter {

	@Override
	public void validate(Field field, Object obj) {
		// TODO Auto-generated method stub
	}

	@Override
	public void mapping(Field field, Object obj, Map<String, String> map) {
		// TODO Auto-generated method stub
	}

}
