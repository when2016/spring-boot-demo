package com.baidu.yun.core.log;

public class NullYunLogHandler implements YunLogHandler {

	public void onHandle(YunLogEvent event) {
		// to nothing
	}

}
