package com.baidu.yun.core.exception;

public class YunHttpClientException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6129408500549568294L;

	public YunHttpClientException(String msg) {
		super(msg);
	}
	
}
