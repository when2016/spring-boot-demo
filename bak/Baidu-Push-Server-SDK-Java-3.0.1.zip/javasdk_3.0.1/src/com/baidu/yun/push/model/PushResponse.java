package com.baidu.yun.push.model;

public abstract class PushResponse {

}
