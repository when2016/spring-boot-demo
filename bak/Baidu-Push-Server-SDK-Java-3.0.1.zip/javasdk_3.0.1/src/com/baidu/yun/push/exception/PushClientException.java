package com.baidu.yun.push.exception;

public class PushClientException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4666593066875898324L;

	public PushClientException(String msg) {
		super(msg);
	}
	
}
